#include <LPC213x.h>

#define RS (1<<14)
#define E  (1<<15)


#define LCD_DATA_MASK (0xFF << 0)

void delay(unsigned int t)
{
    unsigned int i, j;
    for(i=0;i<t;i++)
        for(j=0;j<6000;j++);
}

void lcd_cmd(unsigned char cmd)
{
    IO0CLR = RS;                     
    IO0CLR = LCD_DATA_MASK;          
    IO0SET = (cmd << 0);           

    IO0SET = E;
    delay(1);
    IO0CLR = E;

    delay(2);
}

void lcd_data(unsigned char data)
{
    IO0SET = RS;                     
    IO0CLR = LCD_DATA_MASK;         
    IO0SET = (data << 0);           

    IO0SET = E;
    delay(1);
    IO0CLR = E;

    delay(2);
}

void lcd_init(void)
{
    IO0DIR |= RS | E | LCD_DATA_MASK;

    lcd_cmd(0x38);   
    lcd_cmd(0x0C);   
    lcd_cmd(0x01);   
    delay(5);
    lcd_cmd(0x06);   
}

int main(void)
{
    lcd_init();

    lcd_cmd(0x80);      
    lcd_data('W');
    lcd_data('e');
    lcd_data('l');
    lcd_data('c');
    lcd_data('o');
    lcd_data('m');
    lcd_data('e');

    lcd_cmd(0xC0);      
    lcd_data('t');
    lcd_data('o');
    lcd_data(' ');
    lcd_data('D');
    lcd_data('I');
    lcd_data('E');
    lcd_data('M');
    lcd_data('S');

    while(1);
}